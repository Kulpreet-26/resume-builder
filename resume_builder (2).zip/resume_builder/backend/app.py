from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
CORS(app)

# Database Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///resumes.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Database Model
class Resume(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    education = db.Column(db.Text, nullable=False)
    experience = db.Column(db.Text, nullable=False)
    skills = db.Column(db.Text, nullable=False)

# Routes
@app.route('/resumes', methods=['POST'])
def create_resume():
    data = request.json
    new_resume = Resume(
        name=data['name'],
        email=data['email'],
        phone=data['phone'],
        education=data['education'],
        experience=data['experience'],
        skills=data['skills']
    )
    db.session.add(new_resume)
    db.session.commit()
    return jsonify({"message": "Resume created successfully"}), 201

@app.route('/resumes', methods=['GET'])
def get_resumes():
    resumes = Resume.query.all()
    resume_list = [{"id": r.id, "name": r.name, "email": r.email, "phone": r.phone,
                    "education": r.education, "experience": r.experience, "skills": r.skills}
                   for r in resumes]
    return jsonify(resume_list)

@app.route('/resumes/<int:id>', methods=['DELETE'])
def delete_resume(id):
    resume = Resume.query.get_or_404(id)
    db.session.delete(resume)
    db.session.commit()
    return jsonify({"message": "Resume deleted successfully"})

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)
