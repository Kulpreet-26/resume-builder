import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ResumeForm from "./components/ResumeForm";
import ResumeList from "./components/ResumeList";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<ResumeList />} />
        <Route path="/create" element={<ResumeForm />} />
      </Routes>
    </Router>
  );
}

export default App;
