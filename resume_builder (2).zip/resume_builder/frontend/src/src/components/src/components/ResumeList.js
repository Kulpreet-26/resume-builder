import React, { useEffect, useState } from "react";
import axios from "axios";

const ResumeList = () => {
  const [resumes, setResumes] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/resumes")
      .then((response) => setResumes(response.data))
      .catch((err) => console.error(err));
  }, []);

  const deleteResume = (id) => {
    axios.delete(`http://localhost:5000/resumes/${id}`)
      .then(() => setResumes(resumes.filter((resume) => resume.id !== id)))
      .catch((err) => console.error(err));
  };

  return (
    <div>
      <h1>Resume List</h1>
      <ul>
        {resumes.map((resume) => (
          <li key={resume.id}>
            {resume.name} - {resume.email}
            <button onClick={() => deleteResume(resume.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ResumeList;
