import React, { useState } from "react";
import axios from "axios";

const ResumeForm = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    education: "",
    experience: "",
    skills: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post("http://localhost:5000/resumes", formData)
      .then(() => alert("Resume created!"))
      .catch((err) => console.error(err));
  };

  return (
    <form onSubmit={handleSubmit}>
      <input type="text" name="name" placeholder="Name" onChange={handleChange} required />
      <input type="email" name="email" placeholder="Email" onChange={handleChange} required />
      <input type="text" name="phone" placeholder="Phone" onChange={handleChange} required />
      <textarea name="education" placeholder="Education" onChange={handleChange} required />
      <textarea name="experience" placeholder="Experience" onChange={handleChange} required />
      <textarea name="skills" placeholder="Skills" onChange={handleChange} required />
      <button type="submit">Create Resume</button>
    </form>
  );
};

export default ResumeForm;
